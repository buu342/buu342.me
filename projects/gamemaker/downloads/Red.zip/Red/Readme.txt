������  ������' ������ 
��   �� ��      ��   ��
������  �����'  ��    ��
��   �� ��      ��   ��
��   �� �������'������
                       

BETA VERSION v0.8

**** HOW TO RUN IT *******************

Run Red.exe
Be sure to goto the options if you want to change some settings. If your screen is
incompatible with fullscreen mode and you are stuck in that setting, then be sure
to goto the settings.ini and set fullscreen to 0.


**** Requirements ********************

Windows XP, Vista, 7 or 8
512MB RAM
128MB graphics


**** CONTROLS ************************

WASD 			-	moving
Left Click		-	Shoot
Escape			-	Return to the main menu

In the menu you can move with the arrow keys or with WASD. You can select the button by either clicking it or pressing enter or space.

The Blue cubes restore one health point, however it will not give you more than your maximum health.


**** CREDITS *************************

Programming, graphics, sounds

	Louren�o Soares (buu342)


Music

	CoTeCiO


Original concept by

	Vasco Medeiros (mysterio99999)


Beta Testers

	Josh Peitz
	
	Rico Silva

	Shaun

	Alexander Brigersson

	Vasco Medeiros
	
	Alexandre von Hornstein

	Adrian Velazquez























































You actually read this text file, proud of you <3































































































































Dumbledore kills Snape
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "lgui-waitbox.h"

/**
 ***********************************************************************************************************************
 * Constructor of a wait box
 ***********************************************************************************************************************
 */
WaitBox::WaitBox(QWidget *parent, const QString &message, const QString &title, bool enableAbort) :
	QDialog(parent, Qt::Tool | Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::FramelessWindowHint)
{
	m_ui.setupUi(this);

	connect(m_ui.buttonAbort, SIGNAL(clicked()), this, SLOT(s_abort()));

	m_ui.labelWait->setText(message);
	setWindowTitle(title);
	m_ui.buttonAbort->setEnabled(enableAbort);
}

/**
 ***********************************************************************************************************************
 * Update progress bar
 ***********************************************************************************************************************
 */
void WaitBox::tick()
{
	m_ui.progressBar->setValue((m_ui.progressBar->value() + 4) % 100);

	/*~~~~~~~~~~*/
	bool	close;
	/*~~~~~~~~~~*/

	m_mutex.lock();
	close = m_close;
	m_mutex.unlock();
	if(!close) QTimer::singleShot(200, this, SLOT(tick()));
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void WaitBox::s_abort()
{
	/*~~~~~~~~~~~~*/
	emit	abort();
	/*~~~~~~~~~~~~*/
}

/**
 ***********************************************************************************************************************
 * Start the WaitBox
 ***********************************************************************************************************************
 */
void WaitBox::start()
{
	m_close = false;
	show();
	QTimer::singleShot(5, this, SLOT(tick()));
}

/**
 ***********************************************************************************************************************
 * Stop the WaitBox
 ***********************************************************************************************************************
 */
void WaitBox::stop()
{
	close();
	m_mutex.lock();
	m_close = true;
	m_mutex.unlock();
}

/**
 ***********************************************************************************************************************
 * WaintBox Destructor
 ***********************************************************************************************************************
 */
WaitBox::~WaitBox()
{
}

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_WAITBOX_H
#define LGUI_WAITBOX_H
#include "ui_lgui-waitbox.h"

class WaitBox :
	public QDialog
{
	Q_OBJECT
private:
	QMutex				m_mutex;
	Ui::WaitBoxClass	m_ui;
	bool				m_close;
public:
	WaitBox(QWidget *parent, const QString &message, const QString &title, bool enableAbort = false);
	~	WaitBox();

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	tick();
	void	stop();
	void	start();
	void	s_abort();

	/* Signals */
signals:
	void	abort();
};
#endif // LGUI_WAITBOX_H

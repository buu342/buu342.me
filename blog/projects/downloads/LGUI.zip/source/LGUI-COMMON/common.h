// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_COMMON_H
#define LGUI_COMMON_H

#define OUTPUT_ERROR(e)		"<font style=\"color:red; font-weight:bold\">" + e + "</font>"
#define OUTPUT_WARNING(e)	"<font style=\"color:orange; font-weight:bold\">" + e + "</font>"
#define OUTPUT_GOOD(e)		"<font style=\"color:green;\">" + e + "</font>"

#endif

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef PLUGIN_STRCT_H
#define PLUGIN_STRCT_H

#include <QString>
#include <QStringList>

#define FCTNAME_GET_INFORMATIONS	"?get_informations@@YAPAU_plugin_infos@@XZ"
#define FCTNAME_GET_FUNCTIONS		"?get_functions@@YAPAV?$QList@U_plugin_fct@@@@XZ"
#define FCTNAME_GET_TRANSLATOR		"?get_translator@@YAPAVQTranslator@@XZ"
#define FCGNAME_WIDGET				"?%1@@YAPAVPluginWidget@@XZ"

typedef struct	_plugin_infos
{
	QString name;
	QString version;
	QPixmap icon;
	QString author;
	QString url;
	QString description;
} plugin_infos;

typedef struct	_plugin_fct
{
	QString name;
	QPixmap icon;
	QString callname;
} plugin_fct;

class PluginWidget :
	public QWidget
{
public:
	PluginWidget(QWidget *parent = 0, Qt::WindowFlags f = 0) :
	QWidget(parent, f)
	{
	}

public:
	virtual void interrupt()
	{
	}

signals: ;
	void	message(const QString &message);
};

typedef QList<plugin_fct> * (*fct__get_functions) (void);
typedef plugin_infos * (*fct__get_informations) (void);
typedef QTranslator * (*fct__get_translator) (void);
typedef PluginWidget * (*fct__get_widget) (void);
#endif

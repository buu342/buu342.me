// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>

#define MIN(a, b)	(a < b) ? a : b

#define MAX(a, b)	(a > b) ? a : b

#ifdef DEBUG
#define FLUSH \
	{ \
		field = (field << (32 - field_size)); \
		*((unsigned int *) ctrl) = field; \
		printf("CTRL:0x%X\n", field); \
	}
#else
#define FLUSH \
	{ \
		field = (field << (32 - field_size)); \
		*((unsigned int *) ctrl) = field; \
	}
#endif
#define PUT_BIT(a) \
	{ \
		if(field_size == 32) \
		{ \
			FLUSH	ctrl = out; \
			out += 4; \
			field = 0; \
			field_size = 0; \
		} \
		field = (field << 1) | (a & 0x1); \
		field_size++; \
	}

#define UNROLL(a)	{ while(a != 0) { PUT_BIT(a) a = (a >> 1); PUT_BIT(a) a = (a >> 1); } PUT_BIT(0); }
#define RESERVED	16
#define MIN_SIZE	4
#define COPY \
	{ \
		*(out++) = *(in++); \
	}

#define COPY2 \
	{ \
		*(out++) = *((char *) out_copy); \
		out_copy++; \
	}
#ifdef _DEBUG
#define GET_BIT \
	{ \
		tmp = 0; \
		if(((control) & 0x7FFFFFFF) == 0) \
		{ \
			tmp = control >> 31; \
			data = in; \
			control = (data[0]) | (data[1] << 8) | (data[2] << 16) | (data[3] << 24); \
			printf("Control:0x%X\n", control); \
			in = in + 4; \
		} \
		bit = ((control & 0x80000000) != 0); \
		control = (control << 1) + tmp; \
	}
#else
#define GET_BIT \
	{ \
		tmp = 0; \
		if(((control) & 0x7FFFFFFF) == 0) \
		{ \
			tmp = control >> 31; \
			data = in; \
			control = (data[0]) | (data[1] << 8) | (data[2] << 16) | (data[3] << 24); \
			in = in + 4; \
		} \
		bit = ((control & 0x80000000) != 0); \
		control = (control << 1) + tmp; \
	}
#endif
#define CHECK_BIT	(bit != 0)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */

int decompress(const unsigned char *in, unsigned char *out)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	unsigned char		*out_save = out;
	const unsigned char *data;
	unsigned int		control = 0x80000000;
	unsigned int		tmp;
	unsigned int		bit;
	unsigned int		offset;
	unsigned int		out_copy;
	unsigned int		i;
	unsigned int		j;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	while(1)
	{
		i = 1;
		GET_BIT;
		while(CHECK_BIT)
		{
			for(j = 0; j < i; j++)
			{
				COPY;
			}

			GET_BIT;
			if(CHECK_BIT)
			{
				for(j = 0; j < i; j++)
				{
					COPY;
				}
			}

			i = (i << 1);

			GET_BIT;
		}

		out_copy = *(in++);

		if(out_copy & 0x80)
		{
			out_copy = *(in++) | (out_copy << 8);
			out_copy &= 0x7FFF;

			if(out_copy != 0)
			{
				offset = out_copy;
				out_copy = (unsigned int) out - out_copy;
				COPY2;
				COPY2;
				COPY2;
			}
			else
				return out - out_save;	// Return reading size
		}
		else
		{
			if(out_copy == 0)
			{
				out_copy = (unsigned int) out - offset;
				COPY2;
				COPY2;
				COPY2;
			}
			else
			{
				if(out_copy >= 0x10)
				{
					out_copy = (out_copy << 1) - 0x10;
				}

				out_copy = (unsigned int) out - out_copy;
				COPY2;
				COPY2;
			}
		}

		i = 1;
		GET_BIT;
		while(CHECK_BIT)
		{
			for(j = 0; j < i; j++)
			{
				COPY2;
			}

			GET_BIT;
			if(CHECK_BIT)
			{
				for(j = 0; j < i; j++)
				{
					COPY2;
				}
			}

			i = (i << 1);
			GET_BIT;
		}
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static unsigned int convert(unsigned int size, unsigned int *code)
{
	/*~~~~~~~~~~~~~~~~~~~~*/
	int				off = 0;
	unsigned int	i = 1;
	unsigned int	tmp = 0;
	/*~~~~~~~~~~~~~~~~~~~~*/

	while(off <= 30)
	{
		if(size >= i)
		{
			tmp |= (1 << off);
			size -= i;
		}

		i = (i << 1);
		off += 2;
	}

	off = 31;
	i = (i >> 1);
	while(off >= 1)
	{
		if(size >= i)
		{
			tmp |= (1 << off);
			size -= i;
		}

		i = (i >> 1);
		off -= 2;
	}

	*code = tmp;
	return size;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static unsigned int find2
					(
						const unsigned char *str,
						const unsigned char *str_end,
						const unsigned char *to_find,
						unsigned int		size
					)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	const unsigned char *str_start = str;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	while(str < str_end && size)
	{
		if((*str++) != (*to_find++)) break;
		size--;
	}

	return str - str_start - 1;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static unsigned int find
					(
						const unsigned char *str,
						const unsigned char *str_end,
						const unsigned char *to_find,
						unsigned int		*size
					)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	const unsigned char *found_str;
	unsigned int		found_size = 0;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	while(str < str_end)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		unsigned int	t = find2(str, str_end, to_find, *size);
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		if(t >= found_size)
		{
			found_str = str;
			found_size = t;
		}

		str++;
	}

	*size = found_size;
	return -(found_str - str_end);
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static unsigned int calc_unroll(unsigned int size)
{
	/*~~~~~~~~~~~~~~~~*/
	unsigned int	tmp;
	/*~~~~~~~~~~~~~~~~*/

	convert(size, &tmp);

	/*~~~~~~~~~~~~~~~~~~~~~*/
	unsigned int	tmp2 = 0;
	/*~~~~~~~~~~~~~~~~~~~~~*/

	while(tmp != 0)
	{
		tmp = (tmp >> 2);
		tmp2 += 2;
	}

	tmp2++;
	return tmp2;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
int compress(const unsigned char *in, const unsigned int in_size, unsigned char *out, unsigned int out_size)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	const unsigned char *in_start = in;
	const unsigned char *in_end = in + in_size;
	const unsigned char *out_end = out + out_size - RESERVED;
	const unsigned char *out_start = out;
	unsigned int		offset, tmp, copy_size, uncode_size, j, i;
	unsigned char		*ctrl = out;
	const unsigned char *cpy_src = NULL;
	unsigned int		size = 0;
	unsigned int		field = 0;
	unsigned int		field_size = 0;
	unsigned int		last_offset = 0;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	out += 4;

	while(in <= in_end && (out + size) <= out_end)
	{
		if(in < in_end && (out + size) < out_end)
		{
			if(size >= MIN_SIZE)
			{
				/* Find a reccurent string */
				tmp = (unsigned int) in - 0x7FFF;
				tmp = MAX(tmp, (unsigned int) in_start);
				copy_size = in_end - in;
				offset = find((unsigned char *) tmp, in, in, &copy_size);
			}
			else
				copy_size = 0;
			if(copy_size < MIN_SIZE)
			{
				/* Let copy a string */
				if(cpy_src == NULL)
				{
					cpy_src = in;
				}

				size++;
				in++;
				continue;
			}
		}

		if(size > 0)
		{
			in = cpy_src;
			convert(size, (unsigned int *) &uncode_size);	/* Get control bits field of the size */

			/* Put each bytes */
			i = 1;
			while((uncode_size & 0x1) != 0)
			{
				PUT_BIT(uncode_size);
				uncode_size = (uncode_size >> 1);
				for(j = 0; j < i; j++)
				{
					*out++ = *in++;
				}

				if((uncode_size & 0x1) != 0)
				{
					PUT_BIT(uncode_size);
					uncode_size = (uncode_size >> 1);
					for(j = 0; j < i; j++)
					{
						*out++ = *in++;
					}
				}
				else
				{
					PUT_BIT(uncode_size);
					uncode_size = (uncode_size >> 1);
				}

				i = (i << 1);
			}

			PUT_BIT(uncode_size);

			size = 0;
			cpy_src = NULL;
		}
		else
		{
			PUT_BIT(0);
		}

		if(copy_size >= MIN_SIZE)
		{
#ifdef _DEBUG
			printf("Found\tpos:0x%X\toffset:-0x%X\tsize:0x%X\n", in - in_start, offset, copy_size);
#endif

			// Each copy block control
			if(offset == last_offset)
			{
				*out++ = 0;
				convert(copy_size - 3, (unsigned int *) &uncode_size);	// Size
			}
			else if(offset >= 0x10)
			{
				last_offset = offset;
				*out++ = 0x80 | (offset >> 8);
				*out++ = offset & 0xFF;
				convert(copy_size - 3, (unsigned int *) &uncode_size);	// Size
			}
			else if(offset >= 0x10)
			{
				if(offset & 0x1)
				{
					offset--;
					copy_size--;
				}

				*out++ = (offset >> 1) + 8;
				convert(copy_size - 2, (unsigned int *) &uncode_size);	// Size
			}
			else
			{
				*out++ = offset;
				convert(copy_size - 2, (unsigned int *) &uncode_size);	// Size
			}

			/* Unroll and move */
			UNROLL(uncode_size) in += copy_size;
		}

		if(in >= in_end || (out + size) >= out_end) break;
	}

	/* Flush the last control block */
	FLUSH;

	/* End of the block */
	*out++ = 0x80;
	*out++ = 0x00;

	/* Fill the all block */
	while(out < (out_end + RESERVED)) *out++ = 0xFF;

	return in - in_start;
}

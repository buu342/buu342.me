// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_KP500_H
#define LGUI_KP500_H

typedef struct
{
	char			name[16];
	unsigned int	offset;
	unsigned int	size;
} mem_def;

static mem_def					memory[] =
{
	{ "CALIB", 0x56000000, 0x00014000 },
	{ "STATIC_EEP", 0x544FC000, 0x00014000 },
	{ "DYNAMIC_EEP", 0x54440000, 0x0000A000 },
	{ "DSP", 0x48000000, 0x00080000 },
	{ "UA", 0x47F00000, 0x00064000 },
	{ "CODE1", 0x46F00000, 0x01100000 },
	{ "CODE2", 0x46400000, 0x00B00000 },
	{ "SLB", 0x40000000, 0x000A0000 },
	{ "CLONE", 0x38000000, 0x10800000 },
	{ "PREFLASH", 0x30000000, 0x10800100 },
	{ "DRM", 0x33000000, 0x0003FC00 },
	{ "DEBUG", 0x28000000, 0x0007F800 },
	{ "ROOT_DISK", 0x18000000, 0x01867800 },
	{ "CUST_DISK", 0x10000000, 0x07F00800 },
	{ "USER_DISK", 0x08000000, 0x0300FC00 },
	{ "PSI", 0x00090000, 0x00004000 },
	{ "EBL", 0x00082000, 0x00400000 },
};
static QMap<QString, QString>	portList;

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static void kp500_reduce(const QString &in, const QString &out, unsigned int size)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	/* Ouvre les deux fichiers */
	QFile			in_file(in);
	QFile			out_file(out);
	unsigned int	nb_section;
	char			buff[0x800];
	unsigned int	tmp, tmp2;
	unsigned int	read = 0;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	in_file.open(QIODevice::ReadOnly);
	out_file.open(QIODevice::WriteOnly);

	/* Grab 0x800 of data all the 0x4000 data */
	in_file.seek(0);
	while(read < size)
	{
		tmp = size - read;
		if(tmp > 0x800) tmp = 0x800;
		tmp2 = in_file.read(buff, tmp);
		read += tmp2;
		out_file.write(buff, tmp2);
		if(tmp2 != tmp) break;
		in_file.seek(in_file.pos() + 0x3800);
	}

	memset(buff, 0, 0x800);
	while(read < size)
	{
		tmp = size - read;
		if(tmp > 0x800) tmp = 0x800;
		out_file.write(buff, tmp);
		read += tmp;
	}

	in_file.close();
	out_file.close();
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
static bool GetDeviceNextPort(QString &port, bool init = false)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QString		path = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\USB\\Vid_058b&Pid_0015\\";
	QSettings	settings(path, QSettings::NativeFormat);
	QStringList devices = settings.childGroups();
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	if(devices.size() == 0) throw(NULL);

	for(QStringList::iterator it = devices.begin(); it != devices.end(); ++it)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		QString		&dev = *it;
		QString		sub_path = path + dev + QString("\\Device Parameters");
		QSettings	settings2(sub_path, QSettings::NativeFormat);
		QString		tmp = settings2.value("CreateFileName").toString().left(4);
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		if(init)
		{
			portList[dev] = tmp;
		}
		else
		{
			if(portList[dev] != tmp)
			{
				port = tmp;
				return true;
			}
		}
	}

	return false;
}

class Section :
	public QStandardItem
{
private:
	QString			m_name;
	unsigned int	m_start;
	unsigned int	m_size;
public:
	Section()
	{
		m_start = 0;
		m_size = 0;
	}

	Section(const mem_def &def)
	{
		m_name = def.name;
		m_start = def.offset;
		m_size = def.size;
		setData(m_name + QString(" (0x%1, 0x%2)").arg(m_start, 0, 16).arg(m_size, 0, 16), Qt::DisplayRole);
		setEditable(false);
	}

	const QString &getName()
	{
		return m_name;
	}

	unsigned int getSize()
	{
		return m_size;
	}

	unsigned int getStart()
	{
		return m_start;
	}
};
#endif // LGUI_KP500_H

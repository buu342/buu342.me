// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef IFWD_H
#define IFWD_H
typedef int (*ifwd_callback) (char channel, int deb, int size);
extern "C"
{
__declspec(dllexport)
int __cdecl	_IFWD_DL_upload_bin_image
				(
					char		channel,
					int			deb,
					int			size,
					const char	*szFichier,
					int			write_sam_file,
					char		*resultat
				);
__declspec(dllexport)
int __cdecl	_IFWD_DL_download_bin_image
				(
					char		channel,
					int			deb,
					int			size,
					int			offset,
					const char	*fichier,
					const char	*path,
					char		*resultat
				);
__declspec(dllexport)
int __cdecl	_IFWD_DL_set_dll_parameter(char opt, unsigned int param);
__declspec(dllexport)
int __cdecl	_IFWD_DL_boot_bin_target(char channel, const char *fichier_fls, char *resultat2, char *resultat);
__declspec(dllexport)
char *__cdecl _IFWD_DL_get_dll_version();
__declspec(dllexport)
int __cdecl	_IFWD_DL_open_comm_port
				(
					char			channel,
					const char		*szPort,
					const char		*szPort2,
					unsigned int	speed,
					char			*resultat
				);
__declspec(dllexport)
int __cdecl	_IFWD_DL_close_comm_port(char channel, char *resultat);
__declspec(dllexport)
int __cdecl	_IFWD_DL_force_target_reset(char channel, char, char, char, char, char *);
__declspec(dllexport)
int __cdecl	_IFWD_DL_init_callback(ifwd_callback fct);
}
#endif // IFWD_H

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_UNCOMPRESS_H
#define LGUI_UNCOMPRESS_H

#include <QtGui/QWidget>
#include "ui_lgui-uncompress.h"
#include "../LGUI-COMMON/plugin_strct.h"
#include "../LGUI-COMMON/lgui-waitbox.h"

class UncompressThread :
	public QThread
{
	Q_OBJECT
private:
	QString m_input;
	QString m_output;
public:
	void			set(const QString &input, const QString &output);

	virtual void	run();

signals: ;
	void	message(const QString &message);
};

class UncompressWidget :
	public PluginWidget
{
	Q_OBJECT
public:
	UncompressWidget(QWidget *parent = 0, Qt::WFlags flags = 0);
	~	UncompressWidget();
private:
	WaitBox				m_wb;
	UncompressThread	m_thread;
	Ui::UncompressClass m_ui;

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	s_input();
	void	s_output();
	void	s_convert();
	void	s_message(const QString &str);
signals: ;
	void	message(const QString &message);
};
#endif // LGUI_UNCOMPRESS_H

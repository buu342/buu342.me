// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_COMPRESS_H
#define LGUI_COMPRESS_H

#include <QtGui/QWidget>
#include "ui_lgui-compress.h"
#include "../LGUI-COMMON/plugin_strct.h"
#include "../LGUI-COMMON/lgui-waitbox.h"

class CompressThread :
	public QThread
{
	Q_OBJECT
private:
	QString m_input;
	QString m_output;
public:
	void			set(const QString &input, const QString &output);

	virtual void	run();

signals: ;
	void	message(const QString &message);
};

class CompressWidget :
	public PluginWidget
{
	Q_OBJECT
public:
	CompressWidget(QWidget *parent = 0, Qt::WFlags flags = 0);
	~	CompressWidget();
private:
	WaitBox				m_wb;
	CompressThread		m_thread;
	Ui::CompressClass	m_ui;

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	s_input();
	void	s_output();
	void	s_convert();
	void	s_message(const QString &str);
signals: ;
	void	message(const QString &message);
};
#endif // LGUI_COMPRESS_H

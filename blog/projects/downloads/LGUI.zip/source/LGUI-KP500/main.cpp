// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "resource.h"
#include "lgui-compress.h"
#include "lgui-uncompress.h"
#include "lgui-upload.h"
#include "lgui-download.h"
#include "kp500class.h"

plugin_infos		g_pi;
QTranslator			g_translator;
QList<plugin_fct>	g_fct_lst;
__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_compress()
{
	return new CompressWidget();
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_uncompress()
{
	return new UncompressWidget();
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_download()
{
	return new DownloadWidget();
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_upload()
{
	return new UploadWidget();
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
QTranslator *get_translator()
{
	g_translator.load(INTERNAL_PATH "lang_" + QLocale::system().name().left(2));
	return &g_translator;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
QList<plugin_fct> *get_functions(void)
{
	/*~~~~~~~~~~~~~~~~~~~~*/
	QList<plugin_fct>	lst;
	plugin_fct			fct;
	/*~~~~~~~~~~~~~~~~~~~~*/

	fct.name = KP500class::tr("Compress DMF/SWF/PXO");
	fct.callname = "function_compress";
	fct.icon = QPixmap(INTERNAL_PATH "compress.png");
	g_fct_lst.append(fct);

	fct.name = KP500class::tr("Uncompress DMF/SWF/PXO");
	fct.callname = "function_uncompress";
	fct.icon = QPixmap(INTERNAL_PATH "uncompress.png");
	g_fct_lst.append(fct);

	fct.name = KP500class::tr("Upload");
	fct.callname = "function_upload";
	fct.icon = QPixmap(INTERNAL_PATH "up.png");
	g_fct_lst.append(fct);

	fct.name = KP500class::tr("Download");
	fct.callname = "function_download";
	fct.icon = QPixmap(INTERNAL_PATH "down.png");
	g_fct_lst.append(fct);

	return &g_fct_lst;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
plugin_infos *get_informations(void)
{
	g_pi.name = KP500class::tr("LG KP500");
	g_pi.version = APP_VERSION;
	g_pi.icon = QPixmap(INTERNAL_PATH "kp500.png");
	g_pi.author = APP_AUTHOR;
	g_pi.url = "<A href=\"http://lguiwiki.free.fr\">http://lguiwiki.free.fr</A>";
	g_pi.description = KP500class::tr("Function included:<UL style=\"margin: 0px;\"><LI>Compress files(*.swf, *.dmf, *pxo) for the phone</LI><LI>Uncompress files(*.swf, *.dmf, *pxo) of the phone</LI><LI>Upload file to the phone memory section</LI><LI>Download file of the phone memory section</LI></UL>");

	return &g_pi;
}

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "resource.h"
#include "../LGUI-COMMON/common.h"
#include "lgui-download.h"

/* Specifics */
#include "IFWD.h"
#include "WTypes.h"
#include "Setupapi.h"
#define PORT_ID			1
#define FAST_CRC		6
#define TIMEOUT1		1
#define TIMEOUT2		2
#define SKIP_EMPTY		5
#define SKIP_SECPACK	19
#define SPEED			921600

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadThread::set(const QString &output, const QString &flb, Section &section)
{
	m_output = output;
	m_flb = flb;
	m_section = section;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadThread::interrupt()
{
	m_mutex.lock();
	m_interupted = true;
	m_mutex.unlock();
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadThread::run()
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	emit	message(tr("Start download procedure..."));
	QString path;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	m_mutex.lock();
	m_interupted = false;
	m_mutex.unlock();
	try
	{
		GetDeviceNextPort(path, true);
	}

	catch(...)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_ERROR(tr("Please install the USB driver.")));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		return;
	}

	try
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(tr("DLL version: ") + _IFWD_DL_get_dll_version());
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		_IFWD_DL_set_dll_parameter(SKIP_EMPTY, 1);
		_IFWD_DL_set_dll_parameter(FAST_CRC, 1);
		_IFWD_DL_set_dll_parameter(1, 0x3A98);
		_IFWD_DL_set_dll_parameter(2, 0x3A98);

		/*~~~~~~~~~~~~~~~~~~~*/
		char	str_info[512];
		char	str_info2[512];
		/*~~~~~~~~~~~~~~~~~~~*/

		while(!GetDeviceNextPort(path))
		{
			/*~~~~~~~~~~~~~~~*/
			bool	interupted;
			/*~~~~~~~~~~~~~~~*/

			m_mutex.lock();
			interupted = m_interupted;
			m_mutex.unlock();
			if(interupted) throw(OUTPUT_ERROR(tr("Aborted.")));

			msleep(100);
		}

		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	detected();
		emit	message(tr("USB port: ") + path);
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		path = QString("\\\\.\\") + path;
		if(_IFWD_DL_open_comm_port(PORT_ID, path.toStdString().c_str(), path.toStdString().c_str(), SPEED, str_info))
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			emit	message(OUTPUT_ERROR(tr("Error during USB port opening.")));
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			return;
		}

		try
		{
			if(_IFWD_DL_boot_bin_target(PORT_ID, m_flb.toStdString().c_str(), str_info2, str_info))
			{
				throw(OUTPUT_ERROR(tr("Error during phone booting.")));
			}

			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			emit	message(tr("Download..."));
			QString filename_big = m_output + ".big";
			int		ret = _IFWD_DL_upload_bin_image(PORT_ID, m_section.getStart(), (m_section.getSize() * 0x8),
													filename_big.toStdString().c_str(), 0, str_info);
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			kp500_reduce(filename_big, m_output, m_section.getSize());
			QFile::remove(filename_big);

			if(ret)
			{
				throw(OUTPUT_WARNING(tr("Error during download, may be nothing: \"%1\".").arg(str_info)));
			}

			_IFWD_DL_force_target_reset(PORT_ID, 0, 0, 0, 2, str_info);

			_IFWD_DL_close_comm_port(PORT_ID, str_info);

			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			emit	message(OUTPUT_GOOD(tr("Done.")));
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		}

		catch(QString & str)
		{
			_IFWD_DL_force_target_reset(PORT_ID, 0, 0, 0, 2, str_info);

			_IFWD_DL_close_comm_port(PORT_ID, str_info);
			throw str;
		}
	}

	catch(QString & str)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_ERROR(str));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}

	catch(...)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_ERROR(tr("Unknown error!")));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
DownloadWidget::DownloadWidget(QWidget *parent, Qt::WFlags flags) :
	PluginWidget(parent, flags),
	m_wbDownload(this, tr("Download..."), tr("Wait...")),
	m_wbUSB(this, tr("Plug your phone"), tr("Waiting USB plug..."), true)
{
	m_ui.setupUi(this);
	connect(m_ui.buttonOutput, SIGNAL(clicked()), this, SLOT(s_output()));
	connect(m_ui.buttonFlb, SIGNAL(clicked()), this, SLOT(s_flb()));
	connect(m_ui.buttonDownload, SIGNAL(clicked()), this, SLOT(s_download()));

	connect(&m_thread, SIGNAL(started()), &m_wbUSB, SLOT(start()));
	connect(&m_thread, SIGNAL(detected()), &m_wbUSB, SLOT(stop()));
	connect(&m_thread, SIGNAL(detected()), &m_wbDownload, SLOT(start()));
	connect(&m_thread, SIGNAL(finished()), &m_wbUSB, SLOT(stop()));
	connect(&m_thread, SIGNAL(finished()), &m_wbDownload, SLOT(stop()));
	connect(&m_thread, SIGNAL(message (const QString &)), this, SLOT(s_message (const QString &)));
	connect(&m_wbUSB, SIGNAL(abort()), &m_thread, SLOT(interrupt()));

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QStandardItemModel	*modele = new QStandardItemModel;
	int					length = sizeof(memory) / sizeof(memory[0]);
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Affiche chaque menu */
	for(int i = 0; i < length; i++)
	{
		modele->appendRow(new Section(memory[i]));
	}

	m_ui.comboSection->setModel(modele);
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadWidget::s_output()
{
	/*~~~~~~~~~~~~~~~~~~~~~*/
	QFileDialog dialog(this);
	/*~~~~~~~~~~~~~~~~~~~~~*/

	dialog.setAcceptMode(QFileDialog::AcceptSave);
	dialog.setConfirmOverwrite(true);
	dialog.setWindowIcon(QIcon(INTERNAL_PATH "down.png"));
	dialog.setFileMode(QFileDialog::AnyFile);
	dialog.setNameFilter(tr("All file (*)"));
	if(dialog.exec())
	{
		/*~~~~~~~~~~~~~~~~~~*/
		QStringList fileNames;
		QString		fileName;
		/*~~~~~~~~~~~~~~~~~~*/

		fileNames = dialog.selectedFiles();
		fileName = fileNames.front();
		m_ui.editOutput->setText(fileName);
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadWidget::s_flb()
{
	/*~~~~~~~~~~~~~~~~~~~~~*/
	QFileDialog dialog(this);
	/*~~~~~~~~~~~~~~~~~~~~~*/

	dialog.setWindowIcon(QIcon(INTERNAL_PATH "up.png"));
	dialog.setFileMode(QFileDialog::AnyFile);
	dialog.setNameFilter(tr("FLB file (*.flb)"));

	if(dialog.exec())
	{
		/*~~~~~~~~~~~~~~~~~~*/
		QStringList fileNames;
		QString		fileName;
		/*~~~~~~~~~~~~~~~~~~*/

		fileNames = dialog.selectedFiles();
		fileName = fileNames.front();
		m_ui.editFlb->setText(fileName);
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadWidget::s_download()
{
	if(m_ui.editFlb->text().size() == 0 || m_ui.editOutput->text().size() == 0)
	{
		QMessageBox(QMessageBox::Warning, tr("Invalid FLB/output file."), tr("Select a valid FLB and output file."),
					QMessageBox::Ok, this).exec();
		return;
	}

	try
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		QStandardItemModel	*modele = static_cast<QStandardItemModel *>(m_ui.comboSection->model());
		Section				sec = *reinterpret_cast < Section * > (modele->item(m_ui.comboSection->currentIndex()));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		m_thread.set(m_ui.editOutput->text(), m_ui.editFlb->text(), sec);
		m_thread.start();
	}

	catch(...)
	{
		s_message(OUTPUT_ERROR(tr("Unknown error!")));
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void DownloadWidget::s_message(const QString &msg)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	emit	message(QString("<B>%1:</B> %2").arg(g_pi.name).arg(msg));
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
DownloadWidget::~DownloadWidget()
{
}

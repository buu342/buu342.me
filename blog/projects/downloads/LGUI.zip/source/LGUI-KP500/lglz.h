// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGLZ_H
#define LGLZ_H
int decompress(const unsigned char *in, unsigned char *out);
int compress(const unsigned char *in, const unsigned int in_size, unsigned char *out, unsigned int out_size);
#define BUFOUT_SIZE 8188
#endif

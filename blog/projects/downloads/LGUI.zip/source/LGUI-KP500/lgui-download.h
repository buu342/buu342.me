// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_DOWNLOAD_H
#define LGUI_DOWNLOAD_H

#include <QtGui/QWidget>
#include "ui_lgui-download.h"
#include "../LGUI-COMMON/plugin_strct.h"
#include "../LGUI-COMMON/lgui-waitbox.h"
#include "kp500.h"

class DownloadThread :
	public QThread
{
	Q_OBJECT
private:
	QMutex	m_mutex;
	bool	m_interupted;
	QString m_output;
	QString m_flb;
	Section m_section;
public:
	void			set(const QString &output, const QString &flb, Section &section);
	virtual void	run();

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	interrupt();

signals: ;
	void	message(const QString &message);
	void	detected();
};

class DownloadWidget :
	public PluginWidget
{
	Q_OBJECT
public:
	DownloadWidget(QWidget *parent = 0, Qt::WFlags flags = 0);
	~	DownloadWidget();
private:
	WaitBox				m_wbDownload, m_wbUSB;
	DownloadThread		m_thread;
	Ui::DownloadClass	m_ui;

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	s_output();
	void	s_flb();
	void	s_download();
	void	s_message(const QString &str);
signals: ;
	void	message(const QString &message);
};
#endif // LGUI_DOWNLOAD_H

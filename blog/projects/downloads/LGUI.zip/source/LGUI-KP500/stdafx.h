// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include <QtGui>
#include <exception>
#include "../LGUI-COMMON/plugin_strct.h"
using namespace				std;

extern plugin_infos			g_pi;
extern QTranslator			g_translator;
extern QList<plugin_fct>	g_fct_lst;

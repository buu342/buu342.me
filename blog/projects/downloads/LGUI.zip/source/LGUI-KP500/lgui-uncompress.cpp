// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "resource.h"
#include "../LGUI-COMMON/common.h"
#include "lgui-uncompress.h"

/* Specifics */
#include "lglz.h"

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */

void UncompressThread::set(const QString &input, const QString &output)
{
	m_input = input;
	m_output = output;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void UncompressThread::run()
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	int				size_in;
	int				size_out;
	int				size;
	QFile			file_in(m_input);
	QFile			file_out(m_output);
	emit			message(tr("Uncompressing file..."));
	unsigned char	*out_buffer = new unsigned char[0x100000];
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	try
	{
		/* Open files */
		file_in.open(QIODevice::ReadOnly);
		file_out.open(QIODevice::WriteOnly);

		/* Check file */
		if(!file_in.isOpen() || !file_out.isOpen())
		{
			throw tr("Error during files opening.");
		}

		/* Get the size of input file */
		size_in = file_in.size();

		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		unsigned char	in_buffer[8192];
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		/* Read sizes */
		file_in.read((char *) in_buffer, 4);
		size_out = *((int *) in_buffer);
		file_in.read((char *) in_buffer, 8192);
		size = size_out;	/* Out data size */
		do
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			/* Grab the chunk */
			int a = decompress(in_buffer, out_buffer);
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			file_out.write((char *) out_buffer, a);
			size -= a;
			if(file_in.read((char *) in_buffer, 8192) == 0) break;
		} while(size > 0);

		if(size)
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			emit	message(OUTPUT_WARNING(tr("Incorrect end. The file maybe corrupted.")));
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		}

		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_GOOD(tr("Done.")));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}

	catch(QString & str)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_ERROR(str));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}

	catch(...)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		emit	message(OUTPUT_ERROR(tr("Incorrect compressed file!")));
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	}

	delete[] out_buffer;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
UncompressWidget::UncompressWidget(QWidget *parent, Qt::WFlags flags) :
	PluginWidget(parent, flags),
	m_wb(this, tr("Uncompressing file"), tr("Wait..."))
{
	m_ui.setupUi(this);
	connect(m_ui.buttonInput, SIGNAL(clicked()), this, SLOT(s_input()));
	connect(m_ui.buttonOutput, SIGNAL(clicked()), this, SLOT(s_output()));
	connect(m_ui.buttonUncompress, SIGNAL(clicked()), this, SLOT(s_convert()));
	connect(&m_thread, SIGNAL(started()), &m_wb, SLOT(start()));
	connect(&m_thread, SIGNAL(finished()), &m_wb, SLOT(stop()));
	connect(&m_thread, SIGNAL(message (const QString &)), this, SLOT(s_message (const QString &)));
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void UncompressWidget::s_input()
{
	/*~~~~~~~~~~~~~~~~~~~~~*/
	QFileDialog dialog(this);
	/*~~~~~~~~~~~~~~~~~~~~~*/

	dialog.setWindowIcon(QIcon(INTERNAL_PATH "uncompress.png"));
	dialog.setFileMode(QFileDialog::ExistingFile);
	dialog.setNameFilter(tr("All file (*.*)"));
	if(dialog.exec())
	{
		/*~~~~~~~~~~~~~~~~~~*/
		QStringList fileNames;
		QString		fileName;
		/*~~~~~~~~~~~~~~~~~~*/

		fileNames = dialog.selectedFiles();
		fileName = fileNames.front();
		m_ui.editInput->setText(fileName);
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void UncompressWidget::s_output()
{
	/*~~~~~~~~~~~~~~~~~~~~~*/
	QFileDialog dialog(this);
	/*~~~~~~~~~~~~~~~~~~~~~*/

	dialog.setAcceptMode(QFileDialog::AcceptSave);
	dialog.setConfirmOverwrite(true);
	dialog.setWindowIcon(QIcon(INTERNAL_PATH "uncompress.png"));
	dialog.setFileMode(QFileDialog::AnyFile);
	dialog.setNameFilter(tr("All file (*.*)"));

	if(dialog.exec())
	{
		/*~~~~~~~~~~~~~~~~~~*/
		QStringList fileNames;
		QString		fileName;
		/*~~~~~~~~~~~~~~~~~~*/

		fileNames = dialog.selectedFiles();
		fileName = fileNames.front();
		m_ui.editOutput->setText(fileName);
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void UncompressWidget::s_convert()
{
	if(m_ui.editInput->text().size() == 0 || m_ui.editOutput->text().size() == 0)
	{
		QMessageBox(QMessageBox::Warning, tr("Invalid input/output file."), tr("Select a valid input and output file."),
					QMessageBox::Ok, this).exec();
		return;
	}

	m_thread.set(m_ui.editInput->text(), m_ui.editOutput->text());
	m_thread.start();
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void UncompressWidget::s_message(const QString &msg)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	emit	message(QString("<B>%1:</B> %2").arg(g_pi.name).arg(msg));
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
UncompressWidget::~UncompressWidget()
{
}

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "resource.h"
#include "templateclass.h"

plugin_infos		g_pi;
QTranslator			g_translator;
QList<plugin_fct>	g_fct_lst;
__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_template1()
{
	return NULL;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *function_template2()
{
	return NULL;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
QTranslator *get_translator()
{
	g_translator.load(INTERNAL_PATH "lang_" + QLocale::system().name().left(2));
	return &g_translator;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
QList<plugin_fct> *get_functions(void)
{
	/*~~~~~~~~~~~~~~~~~~~~*/
	QList<plugin_fct>	lst;
	plugin_fct			fct;
	/*~~~~~~~~~~~~~~~~~~~~*/

	fct.name = Templateclass::tr("Template 1");
	fct.callname = "function_template1";
	fct.icon = QPixmap();
	g_fct_lst.append(fct);
	fct.name = Templateclass::tr("Template 2");
	fct.callname = "function_template2";
	fct.icon = QPixmap();
	g_fct_lst.append(fct);
	return &g_fct_lst;
}

__declspec(dllexport)

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
plugin_infos *get_informations(void)
{
	g_pi.name = Templateclass::tr("Template");
	g_pi.version = APP_VERSION;
	g_pi.icon = QPixmap();
	g_pi.author = APP_AUTHOR;
	g_pi.url = "<A href=\"http://lgui.o-n.fr\">http://lgui.o-n.fr</A>";
	g_pi.description = Templateclass::tr("Description template.");

	return &g_pi;
}

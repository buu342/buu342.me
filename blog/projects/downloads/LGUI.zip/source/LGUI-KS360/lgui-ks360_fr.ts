<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>DownloadClass</name>
    <message>
        <location filename="lgui-download.ui" line="14"/>
        <source>Widget</source>
        <translation>Widget</translation>
    </message>
    <message>
        <location filename="lgui-download.ui" line="39"/>
        <location filename="lgui-download.ui" line="65"/>
        <source>Browse...</source>
        <translation>Parcourir...</translation>
    </message>
    <message>
        <location filename="lgui-download.ui" line="52"/>
        <source>Output file path:</source>
        <translation>Chemin du fichier de sortie:</translation>
    </message>
    <message>
        <location filename="lgui-download.ui" line="88"/>
        <source>FLB file path:</source>
        <translation>Chemin du fichier FLB:</translation>
    </message>
    <message>
        <location filename="lgui-download.ui" line="101"/>
        <source>Download</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <location filename="lgui-download.ui" line="124"/>
        <source>Section:</source>
        <translation>Section:</translation>
    </message>
</context>
<context>
    <name>DownloadThread</name>
    <message>
        <location filename="lgui-download.cpp" line="50"/>
        <source>Start download procedure...</source>
        <translation>Démarrage de la procédure de téléchargement...</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="65"/>
        <source>Please install the USB driver.</source>
        <translation>Merci d&apos;installer le driver USB.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="74"/>
        <source>DLL version: </source>
        <translation>Version DLL: </translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="96"/>
        <source>Aborted.</source>
        <translation>Annulé.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="103"/>
        <source>USB port: </source>
        <translation>Port USB: </translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="110"/>
        <source>Error during USB port opening.</source>
        <translation>Erreur durant l&apos;ouverture du port USB.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="120"/>
        <source>Error during phone booting.</source>
        <translation>Erreur durant le démarrage du téléphone.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="124"/>
        <source>Download...</source>
        <translation>Télechargement...</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="135"/>
        <source>Error during download, may be nothing: &quot;%1&quot;.</source>
        <translation>Erreur durant le téléchargement: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="143"/>
        <source>Done.</source>
        <translation>Fini.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="166"/>
        <source>Unknown error!</source>
        <oldsource>Unknown Error!</oldsource>
        <translation>Erreur inconnue!</translation>
    </message>
</context>
<context>
    <name>DownloadWidget</name>
    <message>
        <location filename="lgui-download.cpp" line="178"/>
        <source>Download...</source>
        <translation>Téléchargement...</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="178"/>
        <source>Wait...</source>
        <translation>Patience...</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="179"/>
        <source>Plug your phone</source>
        <translation>Branchez votre téléphone</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="179"/>
        <source>Waiting USB plug...</source>
        <translation>En attente du branchement...</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="223"/>
        <source>All file (*)</source>
        <translation>Tous les fichiers (*.*)</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="250"/>
        <source>FLB file (*.flb)</source>
        <translation>Fichier FLB (*.flb)</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="274"/>
        <source>Invalid FLB/output file.</source>
        <translation>Fichier FLB ou de sortie invalide.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="274"/>
        <source>Select a valid FLB and output file.</source>
        <translation>Sélectionnez un fichier FLB et de sortie valide.</translation>
    </message>
    <message>
        <location filename="lgui-download.cpp" line="292"/>
        <source>Unknown error!</source>
        <oldsource>Unknown Error!</oldsource>
        <translation>Erreur inconnue!</translation>
    </message>
</context>
<context>
    <name>KP500class</name>
    <message>
        <source>Uncompress DMF/SWF/PXO</source>
        <translation type="obsolete">Décompresser DMF/SWF/PXO</translation>
    </message>
    <message>
        <source>Upload</source>
        <translation type="obsolete">Envoyer</translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="obsolete">Télécharger</translation>
    </message>
    <message>
        <source>LG KP500</source>
        <translation type="obsolete">LG KP500</translation>
    </message>
    <message>
        <source>Function included:&lt;UL style=&quot;margin: 0px;&quot;&gt;&lt;LI&gt;Uncompress files(*.swf, *.dmf, *pxo) of the phone&lt;/LI&gt;&lt;/UL&gt;</source>
        <translation type="obsolete">Fonction incluses:&lt;UL style=&quot;margin: 0px;&quot;&gt;&lt;LI&gt;Décompresser des fichiers(*.swf, *.dmf, *pxo) du téléphone&lt;/LI&gt;&lt;/UL&gt;</translation>
    </message>
</context>
<context>
    <name>KS360class</name>
    <message>
        <location filename="main.cpp" line="62"/>
        <source>Upload</source>
        <translation>Envoyer</translation>
    </message>
    <message>
        <location filename="main.cpp" line="66"/>
        <source>Download</source>
        <translation>Télécharger</translation>
    </message>
    <message>
        <location filename="main.cpp" line="82"/>
        <source>LG KS360</source>
        <translation>LG KS360</translation>
    </message>
    <message>
        <location filename="main.cpp" line="87"/>
        <source>Function included:&lt;UL style=&quot;margin: 0px;&quot;&gt;&lt;LI&gt;Upload file to the phone memory section&lt;/LI&gt;&lt;LI&gt;Download file of the phone memory section&lt;/LI&gt;&lt;/UL&gt;</source>
        <oldsource>Function included:&lt;UL style=&quot;margin: 0px;&quot;&gt;&lt;LI&gt;Upload file to the phone memory section&lt;/LI&gt;&lt;LI&gt;Download file to the phone memory section&lt;/LI&gt;&lt;/UL&gt;</oldsource>
        <translation>Fonction incluses:&lt;UL style=&quot;margin: 0px;&quot;&gt;&lt;LI&gt;Envoyer un fichier vers une section mémoire du téléphone&lt;/LI&gt;&lt;LI&gt;Télécharger un fichier d une section mémoire du téléphone&lt;/LI&gt;&lt;/UL&gt;</translation>
    </message>
</context>
<context>
    <name>UncompressClass</name>
    <message>
        <location filename="lgui-uncompress.ui" line="14"/>
        <source>Widget</source>
        <translation>Widget</translation>
    </message>
    <message>
        <location filename="lgui-uncompress.ui" line="39"/>
        <location filename="lgui-uncompress.ui" line="65"/>
        <source>Browse...</source>
        <translation>Parcourir...</translation>
    </message>
    <message>
        <location filename="lgui-uncompress.ui" line="52"/>
        <source>Input file path:</source>
        <translation>Chemin du fichier d&apos;entrée:</translation>
    </message>
    <message>
        <location filename="lgui-uncompress.ui" line="88"/>
        <source>Output file path:</source>
        <translation>Chemin du fichier de sortie:</translation>
    </message>
    <message>
        <location filename="lgui-uncompress.ui" line="101"/>
        <source>Uncompress</source>
        <translation>Décompresser</translation>
    </message>
</context>
<context>
    <name>UncompressThread</name>
    <message>
        <source>Uncompressing file...</source>
        <oldsource>Uncompressing file.</oldsource>
        <translation type="obsolete">Décompression du fichier...</translation>
    </message>
    <message>
        <source>Error during files opening.</source>
        <translation type="obsolete">Erreur durant l&apos;ouverture des fichiers.</translation>
    </message>
    <message>
        <source>Incorrect end. The file maybe corrupted.</source>
        <translation type="obsolete">Fin incorrect. Le fichier est peut être corrompu.</translation>
    </message>
    <message>
        <source>Done.</source>
        <translation type="obsolete">Fini.</translation>
    </message>
    <message>
        <source>Incorrect compressed file!</source>
        <translation type="obsolete">Fichier compressé incorrect!</translation>
    </message>
</context>
<context>
    <name>UncompressWidget</name>
    <message>
        <source>Uncompressing file</source>
        <oldsource>Uncompress file</oldsource>
        <translation type="obsolete">Décompression du fichier</translation>
    </message>
    <message>
        <source>All file (*.*)</source>
        <translation type="obsolete">Tous les fichiers (*.*)</translation>
    </message>
    <message>
        <source>Invalid input/output file.</source>
        <translation type="obsolete">Fichier d&apos;entrée ou de sortie invalide.</translation>
    </message>
    <message>
        <source>Select a valid input and output file.</source>
        <translation type="obsolete">Sélectionnez un fichier d&apos;entrée et de sorite valide.</translation>
    </message>
</context>
<context>
    <name>UploadClass</name>
    <message>
        <location filename="lgui-upload.ui" line="14"/>
        <source>Widget</source>
        <translation>Widget</translation>
    </message>
    <message>
        <location filename="lgui-upload.ui" line="39"/>
        <location filename="lgui-upload.ui" line="65"/>
        <source>Browse...</source>
        <translation>Parcourir...</translation>
    </message>
    <message>
        <location filename="lgui-upload.ui" line="52"/>
        <source>Input file path:</source>
        <translation>Chemin du fichier d&apos;entrée:</translation>
    </message>
    <message>
        <location filename="lgui-upload.ui" line="88"/>
        <source>FLB file path:</source>
        <translation>Chemin du fichier FLB:</translation>
    </message>
    <message>
        <location filename="lgui-upload.ui" line="101"/>
        <source>Upload</source>
        <translation>Envoyer</translation>
    </message>
    <message>
        <location filename="lgui-upload.ui" line="124"/>
        <source>Section:</source>
        <translation>Section:</translation>
    </message>
</context>
<context>
    <name>UploadThread</name>
    <message>
        <location filename="lgui-upload.cpp" line="50"/>
        <source>Start upload procedure...</source>
        <translation>Démarrage de la procédure d&apos;envoi...</translation>
    </message>
    <message>
        <source>Please install the USB driver.</source>
        <translation type="obsolete">Merci d&apos;installer le driver USB.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="65"/>
        <source>No USB driver.</source>
        <translation>Pas de driver USB.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="74"/>
        <source>DLL version: </source>
        <translation>Version DLL: </translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="96"/>
        <source>Aborted.</source>
        <translation>Annulé.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="103"/>
        <source>USB port: </source>
        <translation>Port USB: </translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="110"/>
        <source>Error during USB port opening.</source>
        <translation>Erreur durant l&apos;ouverture du port USB.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="120"/>
        <source>Error during phone booting.</source>
        <translation>Erreur durant le démarrage du téléphone.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="124"/>
        <source>Upload...</source>
        <translation>Envoi...</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="133"/>
        <source>Error during upload: &quot;%1&quot;.</source>
        <translation>Erreur durant l&apos;envoi: &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="141"/>
        <source>Done.</source>
        <translation>Fini.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="165"/>
        <source>Unknown error!</source>
        <oldsource>Unknown Error!</oldsource>
        <translation>Erreur inconnue!</translation>
    </message>
</context>
<context>
    <name>UploadWidget</name>
    <message>
        <location filename="lgui-upload.cpp" line="177"/>
        <source>Upload...</source>
        <translation>Envoi...</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="177"/>
        <source>Wait...</source>
        <translation>Patience...</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="178"/>
        <source>Plug your phone</source>
        <translation>Branchez votre téléphone</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="178"/>
        <source>Waiting USB plug...</source>
        <translation>En attente du branchement...</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="220"/>
        <source>All file (*)</source>
        <translation>Tous les fichiers (*.*)</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="247"/>
        <source>FLB file (*.flb)</source>
        <translation>Fichier FLB (*.flb)</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="271"/>
        <source>Invalid input/FLB file.</source>
        <translation>Fichier d&apos;entrée ou FLB invalide.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="271"/>
        <source>Select a valid input and FLB file.</source>
        <translation>Sélectionnez un fichier d&apos;entrée et FLB valide.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="284"/>
        <location filename="lgui-upload.cpp" line="308"/>
        <source>Upload</source>
        <translation>Envoyer</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="285"/>
        <source>Are you sure to upload this file on &lt;B&gt;%1&lt;/B&gt;? Tts content will be rewrited!</source>
        <oldsource>Are you sure to upload this file on &lt;B&gt;%1&lt;/B&gt;? its content will be rewrited!</oldsource>
        <translation>Etes vous sur de vouloir envoyer le fichier sur &lt;B&gt;%1&lt;/B&gt;? Son contenu va être réecrit!</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="294"/>
        <location filename="lgui-upload.cpp" line="318"/>
        <source>Aborted.</source>
        <translation>Annulée.</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="309"/>
        <source>The file haven&apos;t the same size that &lt;B&gt;%1&lt;/B&gt;! Are you sure to want to upload this file?</source>
        <oldsource>The file haven&apos;t the same size that &lt;B&gt;%1&lt;/B&gt;? are you sure to want to upload this file!</oldsource>
        <translation>Le fichier n&apos;est pas de la même taille que &lt;B&gt;%1&lt;/B&gt;! Etes vous sur de vouloir envoyer ce fichier?</translation>
    </message>
    <message>
        <location filename="lgui-upload.cpp" line="330"/>
        <source>Unknown error!</source>
        <oldsource>Unknown Error!</oldsource>
        <translation>Erreur inconnue!</translation>
    </message>
</context>
<context>
    <name>WaitBoxClass</name>
    <message>
        <source>Wait...</source>
        <translation type="obsolete">Patience...</translation>
    </message>
    <message>
        <location filename="../LGUI-COMMON/lgui-waitbox.ui" line="38"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../LGUI-COMMON/lgui-waitbox.ui" line="79"/>
        <source>Abort</source>
        <translation>Annuler</translation>
    </message>
</context>
</TS>

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_RESOURCE_H
#define LGUI_RESOURCE_H

#define INTERNAL_NAME		"ks360"
#define INTERNAL_PATH		":/"INTERNAL_NAME "/"

#define APP_VERSION			"0.0.1"
#define APP_NAME			"KS360"
#define APP_AUTHOR			"Blackhorn"

#define V_PRODUCTVERSION	0, 0, 1, 0
#define V_FILEVERSION		0, 0, 1, 0
#endif

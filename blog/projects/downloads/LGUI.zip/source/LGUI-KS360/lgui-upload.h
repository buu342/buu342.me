// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_UPLOAD_H
#define LGUI_UPLOAD_H

#include <QtGui/QWidget>
#include "ui_lgui-upload.h"
#include "../LGUI-COMMON/plugin_strct.h"
#include "../LGUI-COMMON/lgui-waitbox.h"
#include "ks360.h"

class UploadThread :
	public QThread
{
	Q_OBJECT
private:
	QMutex	m_mutex;
	bool	m_interupted;
	QString m_input;
	QString m_flb;
	Section m_section;
public:
	void			set(const QString &input, const QString &flb, Section &section);
	virtual void	run();

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	interrupt();

signals: ;
	void	message(const QString &message);
	void	detected();
};

class UploadWidget :
	public PluginWidget
{
	Q_OBJECT
public:
	UploadWidget(QWidget *parent = 0, Qt::WFlags flags = 0);
	~	UploadWidget();
private:
	WaitBox			m_wbUpload, m_wbUSB;
	UploadThread	m_thread;
	Ui::UploadClass m_ui;

	/**
	 *******************************************************************************************************************
	 * Slots
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	s_input();
	void	s_flb();
	void	s_upload();
	void	s_message(const QString &str);
signals: ;
	void	message(const QString &message);
};
#endif // LGUI_UPLOAD_H

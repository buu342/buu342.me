// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_QTEXTEDITEX_H
#define LGUI_QTEXTEDITEX_H
class QTextEditEx :
	public QTextEdit
{
	Q_OBJECT
public:
	QTextEditEx(QWidget *parent = 0) :
	QTextEdit(parent)
	{
	}

/**
 ***********************************************************************************************************************
 * Virtual Implementation
 ***********************************************************************************************************************
 */
private:
	virtual void contextMenuEvent(QContextMenuEvent *ev)
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~*/
		QMenu	*menu = new QMenu();
		/*~~~~~~~~~~~~~~~~~~~~~~~~*/

		menu->addAction(tr("Clear"), this, SLOT(clear()));
		menu->addAction(tr("Select All"), this, SLOT(selectAll()));
		menu->exec(ev->globalPos());
	}
};
#endif

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_H
#define LGUI_H

#include "ui_lgui.h"
#include "Plugin.h"
class LGUI :
	public QMainWindow
{
	Q_OBJECT
public:
	LGUI(QWidget *parent = 0, Qt::WFlags flags = 0);
	~	LGUI();
private:
	QList<Plugin *> m_plugins;
	Ui::LGUIClass	m_ui;
	PluginWidget	*m_plugin_widget;
	Plugin			*m_current_plugin;
private:
	void	default_info();
	void	show_info();
	void	hide_info();
	void	load_plugins();
	void	unload_plugins();
	void	attach(PluginWidget *widget);
	void	dettach();
	void	select_plugin(Plugin &plugin);
	void	run_plugin_function(Plugin &plugin, const QString &function_name);
	void	appendOutput(const QString &str);



	/**
	 *******************************************************************************************************************
	 * SLOTS
	 *******************************************************************************************************************
	 */
	public slots : ;
	void	s_about();
	void	s_exit();
	void	s_reload_plugins();
	void	s_select_plugin(const QModelIndex &index);
	void	s_message(const QString &str);
};
#endif // LGUI_H

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "lgui.h"
#include "plugin.h"
#include "resource.h"
#include "../LGUI-COMMON/common.h"

#define ICON				"<IMG src=\"%1\" style=\"float: right;\"/>"
#define NAME_FORMAT			"<font style=\"font-weight:bold\">%1: </font>%2<BR>"
#define AUTHOR_FORMAT		"<font style=\"font-weight:bold\">%1: </font>%2<BR>"
#define VERSION_FORMAT		"<font style=\"font-weight:bold\">%1: </font>%2<BR>"
#define URL_FORMAT			"<font style=\"font-weight:bold\">%1: </font>%2<BR>"
#define DESCRIPTION_FORMAT	"<BR><U><font style=\"font-weight:bold\">%1</font></U><BR>%2"

/**
 ***********************************************************************************************************************
 * Main Window of the program
 ***********************************************************************************************************************
 */
LGUI::LGUI(QWidget *parent, Qt::WFlags flags) :
	QMainWindow(parent, flags)
{
	m_ui.setupUi(this);
	setWindowTitle(tr("%1 - %2").arg(APP_NAME).arg(APP_VERSION));
	setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &~Qt::WindowMaximizeButtonHint);
	setFixedSize(size());
	m_ui.textOutput->insertHtml(tr("<B>%1 - %2</B> by %3").arg(APP_NAME).arg(APP_VERSION).arg(APP_AUTHOR));

	m_ui.textPlugin->viewport()->setAutoFillBackground(false);
	m_ui.treePlugin->header()->setVisible(false);
	m_ui.widget->setLayout(new QStackedLayout());

	m_plugin_widget = NULL;
	m_current_plugin = NULL;

	/* Slots */
	connect(m_ui.actionAbout, SIGNAL(triggered()), this, SLOT(s_about()));
	connect(m_ui.actionExit, SIGNAL(triggered()), this, SLOT(s_exit()));
	connect(m_ui.actionReload, SIGNAL(triggered()), this, SLOT(s_reload_plugins()));
	connect(m_ui.treePlugin, SIGNAL(clicked (const QModelIndex &)), this, SLOT(s_select_plugin (const QModelIndex &)));
	default_info();
	load_plugins();
}

/**
 ***********************************************************************************************************************
 * Load default information about the program
 ***********************************************************************************************************************
 */
void LGUI::default_info()
{
	m_ui.treePlugin->clearSelection();

	// Set the new informations
	m_ui.textPlugin->clear();
	m_ui.textPlugin->document()->clear();
	m_ui.textPlugin->document()->addResource(QTextDocument::ImageResource, QUrl("logo.png"), QPixmap(":/logo.png"));
	m_ui.textPlugin->insertHtml(tr(ICON).arg("logo.png"));

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QString content = QString("<font style=\"font-size: 40px; font-weight: bold;\">%1</font>&nbsp;&nbsp;&nbsp;%2<br>").arg(APP_NAME).arg(APP_VERSION);
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	content += tr("By %1<br>Thanks to Glx & Hayk<br><br><A href=\"http://lguiwiki.free.fr\">http://lguiwiki.free.fr</A><br><br><br><br>").arg(APP_AUTHOR);
	content += tr("<U><B>Disclaimer of Warranties</B></U><br>The software is provided to you \"as is\", with all faults,"
				  " without warranty of any kind, and your use is at your sole risk. The entire risk of satisfactory quality"
			  " and performance resides with you. %1 do not make, and hereby disclaim, any and all express, implied or"
		  " statutory warranties, including implied warranties of merchantability, satisfactory quality, fitness for"
	  " a particular purpose, noninfringement of third party rights, and warranties (if any) arising from a course"
  " of dealing, usage, or trade practice. %1 does not warrant against interference with your enjoyment of the software;"
" that the software will meet your requirements; that operation of the software will be uninterrupted or error-free,"
" or that the software will be compatible with third party software or that any errors in the software will be corrected.").arg(APP_AUTHOR);
	m_ui.textPlugin->insertHtml(content);
	show_info();
}

/**
 ***********************************************************************************************************************
 * Show the info panel
 ***********************************************************************************************************************
 */
void LGUI::show_info()
{
	// Detach
	dettach();
	m_ui.textPlugin->setVisible(true);
}

/**
 ***********************************************************************************************************************
 * Hide the info panel
 ***********************************************************************************************************************
 */
void LGUI::hide_info()
{
	m_ui.textPlugin->setVisible(false);
}

/**
 ***********************************************************************************************************************
 * attach a plugin to the central widget
 ***********************************************************************************************************************
 */
void LGUI::attach(PluginWidget *widget)
{
	dettach();

	m_plugin_widget = widget;
	connect(m_plugin_widget, SIGNAL(message (const QString &)), this, SLOT(s_message (const QString &)));
}

/**
 ***********************************************************************************************************************
 * detache the plugin of the central widget
 ***********************************************************************************************************************
 */
void LGUI::dettach()
{
	if(m_plugin_widget != NULL)
	{
		disconnect(m_plugin_widget, SIGNAL(message (const QString &)), this, SLOT(s_message (const QString &)));

		m_ui.widget->layout()->removeWidget(m_plugin_widget);
		delete m_plugin_widget;
		m_plugin_widget = NULL;
	}
}

/**
 ***********************************************************************************************************************
 * Add a message into the Output textbox
 ***********************************************************************************************************************
 */
void LGUI::appendOutput(const QString &str)
{
	m_ui.textOutput->moveCursor(QTextCursor::End, QTextCursor::MoveAnchor);
	if(!m_ui.textOutput->document()->isEmpty()) m_ui.textOutput->insertHtml("<BR>");
	m_ui.textOutput->insertHtml(str);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QScrollBar	*sb = m_ui.textOutput->verticalScrollBar();
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	sb->setValue(sb->maximum());
}

/**
 ***********************************************************************************************************************
 * Select a plugin -> Show information of this plugin
 ***********************************************************************************************************************
 */
void LGUI::select_plugin(Plugin &plugin)
{
	m_current_plugin = &plugin;

	// Delete previous informations
	m_ui.textPlugin->clear();
	m_ui.textPlugin->document()->clear();

	// Set the new informations
	m_ui.textPlugin->document()->addResource(QTextDocument::ImageResource, QUrl("icon.png"),
											 plugin.getInformations().icon);

	m_ui.textPlugin->insertHtml(QString(ICON).arg("icon.png"));
	m_ui.textPlugin->insertHtml(QString(NAME_FORMAT).arg(tr("Name")).arg(plugin.getInformations().name));
	m_ui.textPlugin->insertHtml(QString(VERSION_FORMAT).arg(tr("Version")).arg(plugin.getInformations().version));
	m_ui.textPlugin->insertHtml(QString(AUTHOR_FORMAT).arg(tr("Author")).arg(plugin.getInformations().author));
	m_ui.textPlugin->insertHtml(QString(URL_FORMAT).arg(tr("URL")).arg(plugin.getInformations().url));
	m_ui.textPlugin->insertHtml(QString(DESCRIPTION_FORMAT).arg(tr("Description")).arg(plugin.getInformations().description));
	show_info();
}

/**
 ***********************************************************************************************************************
 * Grab back the widget of the select function plugin
 ***********************************************************************************************************************
 */
void LGUI::run_plugin_function(Plugin &plugin, const QString &function_name)
{
	appendOutput(tr("Loading <B>%1</B> of <B>%2</B>...").arg(function_name).arg(plugin.getInformations().name));
	try
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		PluginWidget	*widget = plugin.runFunction(function_name);
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		hide_info();
		attach(widget);
		m_ui.widget->layout()->addWidget(widget);
		appendOutput(OUTPUT_GOOD(tr("Done.")));
	}

	catch(QString & txt)
	{
		appendOutput(OUTPUT_ERROR(txt));
	}

	catch(...)
	{
		appendOutput(OUTPUT_ERROR(tr("Unknown error!")));
	}
}

/**
 ***********************************************************************************************************************
 * Load the existing plugins into TreePlugin
 ***********************************************************************************************************************
 */
void LGUI::load_plugins()
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QStandardItemModel	*modele = new QStandardItemModel;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	appendOutput(tr("Loading plugins..."));
	try
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		QDir		currentDir(PLUGINS_PATH);
		QStringList files;
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		if(!currentDir.exists()) throw(tr("Plugin directory not found."));
		files = currentDir.entryList(QStringList("*.dll"));

		for(QStringList::const_iterator it = files.begin(); it != files.end(); ++it)
		{
			try
			{
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
				Plugin	*plugin = new Plugin(*it);
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

				m_plugins.append(plugin);
				modele->appendRow(plugin);
				appendOutput(OUTPUT_GOOD(tr("The plugin <B>%1</B> is loaded.").arg(*it)));
			}

			catch(QString & txt)
			{
				appendOutput(OUTPUT_WARNING(txt));
			}
		}

		m_ui.treePlugin->setModel(modele);
		m_ui.treePlugin->expandAll();
	}

	catch(QString & txt)
	{
		delete modele;
		appendOutput(OUTPUT_ERROR(txt));
	}

	catch(...)
	{
		delete modele;
		appendOutput(OUTPUT_ERROR(tr("Unknown error!")));
	}

	appendOutput(tr("Loading plugins: Done."));
}

/**
 ***********************************************************************************************************************
 * Unload plugins
 ***********************************************************************************************************************
 */
void LGUI::unload_plugins()
{
	default_info();

	m_current_plugin = NULL;

	appendOutput(tr("Unloading plugins..."));
	while(m_plugins.size())
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		Plugin	*plugin = m_plugins.front();
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		delete plugin;
		m_plugins.pop_front();
	}

	appendOutput(tr("Unloading plugins: Done."));
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void LGUI::s_about()
{
	default_info();
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
void LGUI::s_message(const QString &str)
{
	appendOutput(str);
}

/**
 ***********************************************************************************************************************
 * Click on one item of the TreePlugin
 ***********************************************************************************************************************
 */
void LGUI::s_select_plugin(const QModelIndex &index)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QStandardItemModel	*model = static_cast<QStandardItemModel *>(m_ui.treePlugin->model());
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	try
	{
		if(model != NULL)
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			QStandardItem	*item = model->itemFromIndex(index);
			QStandardItem	*plugin = item;
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			while(plugin->parent() != NULL)
			{
				plugin = plugin->parent();
			}

			if(plugin == item)
			{
				select_plugin(*dynamic_cast<Plugin *>(plugin));
			}
			else
			{
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
				QString str = item->data().toString();
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

				run_plugin_function(*dynamic_cast<Plugin *>(plugin), str);
			}
		}
	}

	catch(...)
	{
		appendOutput(OUTPUT_ERROR(tr("Unknown error!")));
	}
}

/**
 ***********************************************************************************************************************
 * Reload the plugins
 ***********************************************************************************************************************
 */
void LGUI::s_reload_plugins()
{
	unload_plugins();
	load_plugins();
	default_info();
}

/**
 ***********************************************************************************************************************
 * Quit
 ***********************************************************************************************************************
 */
void LGUI::s_exit()
{
	unload_plugins();
	close();
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
LGUI::~LGUI()
{
}

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>LGUI</name>
    <message>
        <location filename="lgui.cpp" line="23"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="26"/>
        <source>&lt;B&gt;%1 - %2&lt;/B&gt; by %3</source>
        <oldsource>&lt;B&gt;%1 - %2&lt;/B&gt; Made by %3</oldsource>
        <translation>&lt;B&gt;%1 - %2&lt;/B&gt; Par %3</translation>
    </message>
    <message>
        <source>By %1&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;U&gt;&lt;B&gt;Disclaimer of Warranties&lt;/B&gt;&lt;/U&gt;&lt;br&gt;The software is provided to you &quot;as is&quot;, with all faults, without warranty of any kind, and your use is at your sole risk. The entire risk of satisfactory quality and performance resides with you. %1 do not make, and hereby disclaim, any and all express, implied or statutory warranties, including implied warranties of merchantability, satisfactory quality, fitness for a particular purpose, noninfringement of third party rights, and warranties (if any) arising from a course of dealing, usage, or trade practice. %1 does not warrant against interference with your enjoyment of the software; that the software will meet your requirements; that operation of the software will be uninterrupted or error-free, or that the software will be compatible with third party software or that any errors in the software will be corrected.</source>
        <oldsource>By %1&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;The software is provided to you &quot;as is&quot;, with all faults, without warranty of any kind, and your use is at your sole risk. The entire risk of satisfactory quality and performance resides with you. %1 do not make, and hereby disclaim, any and all express, implied or statutory warranties, including implied warranties of merchantability, satisfactory quality, fitness for a particular purpose, noninfringement of third party rights, and warranties (if any) arising from a course of dealing, usage, or trade practice. %1 does not warrant against interference with your enjoyment of the software; that the software will meet your requirements; that operation of the software will be uninterrupted or error-free, or that the software will be compatible with third party software or that any errors in the software will be corrected.</oldsource>
        <translation type="obsolete">Par %1&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;U&gt;&lt;B&gt;Non Garantie&lt;/B&gt;&lt;/U&gt;&lt;br&gt;Le logiciel vous est fourni « en l’état », sans défaut, sans garantie d&apos;aucune sorte, et vous l&apos;utilisez a vos propres risques. Vous assumez la totalité des risques en matière de performance et de qualité. %1 n&apos;offre aucune garantie, et décline par la présente toute garantie, expresse ou implicite, de qualité et d&apos;aptitude à l&apos;utilisation prévue ou contre les vices caches ou de non violation des droits de tiers. %1 n&apos;offre aucune garantie en matière d&apos;interférence dans votre utilisation du logiciel ; aucune garantie selon laquelle le logiciel répondrait à vos attentes ; ou selon laquelle le fonctionnement du logiciel serait ininterrompu ou exempt d&apos;erreur, ou selon laquelle le logiciel serait compatible avec les logiciels de tiers ou selon laquelle d&apos;éventuelles erreurs dans le logiciel seraient corrigées.</translation>
    </message>
    <message>
        <source>By %1&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">Par %1&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>By %1&lt;br&gt;Thanks to Glx &amp; Hayk&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</source>
        <translation type="obsolete">Par %1&lt;br&gt;Merci à Glx &amp; Hayk&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="63"/>
        <source>By %1&lt;br&gt;Thanks to Glx &amp; Hayk&lt;br&gt;&lt;br&gt;&lt;A href=&quot;http://lguiwiki.free.fr&quot;&gt;http://lguiwiki.free.fr&lt;/A&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</source>
        <oldsource>By %1&lt;br&gt;Thanks to Glx &amp; Hayk&lt;br&gt;&lt;br&gt;&lt;A href=&quot;http://lgui.o-n.fr&quot;&gt;http://lgui.o-n.fr&lt;/A&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</oldsource>
        <translation>Par %1&lt;br&gt;Merci à Glx &amp; Hayk&lt;br&gt;&lt;br&gt;&lt;A href=&quot;http://lguiwiki.free.fr&quot;&gt;http://lguiwiki.free.fr&lt;/A&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="64"/>
        <source>&lt;U&gt;&lt;B&gt;Disclaimer of Warranties&lt;/B&gt;&lt;/U&gt;&lt;br&gt;The software is provided to you &quot;as is&quot;, with all faults, without warranty of any kind, and your use is at your sole risk. The entire risk of satisfactory quality and performance resides with you. %1 do not make, and hereby disclaim, any and all express, implied or statutory warranties, including implied warranties of merchantability, satisfactory quality, fitness for a particular purpose, noninfringement of third party rights, and warranties (if any) arising from a course of dealing, usage, or trade practice. %1 does not warrant against interference with your enjoyment of the software; that the software will meet your requirements; that operation of the software will be uninterrupted or error-free, or that the software will be compatible with third party software or that any errors in the software will be corrected.</source>
        <translation>&lt;U&gt;&lt;B&gt;Non Garantie&lt;/B&gt;&lt;/U&gt;&lt;br&gt;Le logiciel vous est fourni « en l’état », sans défaut, sans garantie d&apos;aucune sorte, et vous l&apos;utilisez a vos propres risques. Vous assumez la totalité des risques en matière de performance et de qualité. %1 n&apos;offre aucune garantie, et décline par la présente toute garantie, expresse ou implicite, de qualité et d&apos;aptitude à l&apos;utilisation prévue ou contre les vices caches ou de non violation des droits de tiers. %1 n&apos;offre aucune garantie en matière d&apos;interférence dans votre utilisation du logiciel ; aucune garantie selon laquelle le logiciel répondrait à vos attentes ; ou selon laquelle le fonctionnement du logiciel serait ininterrompu ou exempt d&apos;erreur, ou selon laquelle le logiciel serait compatible avec les logiciels de tiers ou selon laquelle d&apos;éventuelles erreurs dans le logiciel seraient corrigées.</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="164"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="165"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="166"/>
        <source>Author</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="167"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="168"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="179"/>
        <source>Loading &lt;B&gt;%1&lt;/B&gt; of &lt;B&gt;%2&lt;/B&gt;...</source>
        <oldsource>Loading &lt;B&gt;%1&lt;/B&gt; of &lt;B&gt;%2&lt;/B&gt;</oldsource>
        <translation>Lancement &lt;B&gt;%1&lt;/B&gt; de &lt;B&gt;%2&lt;/B&gt;...</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="189"/>
        <source>Done.</source>
        <translation>Fini.</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="199"/>
        <location filename="lgui.cpp" line="257"/>
        <location filename="lgui.cpp" line="350"/>
        <source>Unknown error!</source>
        <oldsource>Unknown Error!</oldsource>
        <translation>Erreur inconnue!</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="214"/>
        <source>Loading plugins...</source>
        <translation>Chargement des plugins...</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="222"/>
        <source>Plugin directory not found.</source>
        <oldsource>Plugin directory not found</oldsource>
        <translation>Repertoire des plugins introuvé.</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="235"/>
        <source>The plugin &lt;B&gt;%1&lt;/B&gt; is loaded.</source>
        <translation>Le plugin &lt;B&gt;%1&lt;/B&gt; est chargé.</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="260"/>
        <source>Loading plugins: Done.</source>
        <translation>Chargement des plugins fini.</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="274"/>
        <source>Unloading plugins...</source>
        <translation>Déchargement des plugins...</translation>
    </message>
    <message>
        <location filename="lgui.cpp" line="285"/>
        <source>Unloading plugins: Done.</source>
        <translation>Déchargement des plugins fini.</translation>
    </message>
</context>
<context>
    <name>LGUIClass</name>
    <message>
        <location filename="lgui.ui" line="14"/>
        <source>LGUI</source>
        <translation>LGUI</translation>
    </message>
    <message>
        <location filename="lgui.ui" line="117"/>
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location filename="lgui.ui" line="127"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="lgui.ui" line="136"/>
        <source>Exit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="lgui.ui" line="145"/>
        <source>Reload plugins</source>
        <translation>Recharger les plugins</translation>
    </message>
    <message>
        <location filename="lgui.ui" line="150"/>
        <source>About</source>
        <translation>A Propos</translation>
    </message>
</context>
<context>
    <name>Plugin</name>
    <message>
        <location filename="plugin.cpp" line="21"/>
        <source>The plugin &lt;I&gt;%1&lt;/I&gt; can&apos;t be loaded!</source>
        <translation>Le plugin &lt;I&gt;%1&lt;/I&gt; ne peut pas être chargé!</translation>
    </message>
    <message>
        <location filename="plugin.cpp" line="33"/>
        <location filename="plugin.cpp" line="69"/>
        <source>The plugin &lt;I&gt;%1&lt;/I&gt; is an invalid %2 plugin!</source>
        <translation>Tle plugin &lt;I&gt;%1&lt;/I&gt; est un plugin invalide de %2!</translation>
    </message>
    <message>
        <location filename="plugin.cpp" line="98"/>
        <location filename="plugin.cpp" line="108"/>
        <location filename="plugin.cpp" line="121"/>
        <source>The function &lt;I&gt;%1&lt;/I&gt; of &lt;I&gt;%2&lt;/I&gt; is an invalid function!</source>
        <translation>La fonction &lt;I&gt;%1&lt;/I&gt; de &lt;I&gt;%2&lt;/I&gt; est une fonction invalide!</translation>
    </message>
    <message>
        <location filename="plugin.cpp" line="116"/>
        <source>The function &lt;I&gt;%1&lt;/I&gt; of &lt;I&gt;%2&lt;/I&gt; doesn&apos;t exist!</source>
        <translation>La fonction &lt;I&gt;%1&lt;/I&gt; de &lt;I&gt;%2&lt;/I&gt; n&apos;existe pas!</translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <location filename="qtexteditex.h" line="25"/>
        <source>Clear</source>
        <translation>Effacer</translation>
    </message>
    <message>
        <location filename="qtexteditex.h" line="26"/>
        <source>Select All</source>
        <translation>Tout sélectionner</translation>
    </message>
</context>
</TS>

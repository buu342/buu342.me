// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef LGUI_RESOURCE_H
#define LGUI_RESOURCE_H
#define APP_VERSION			"0.0.2"
#define APP_NAME			"LGUI"
#define APP_AUTHOR			"Blackhorn"

#define V_PRODUCTVERSION	0, 0, 2, 0
#define V_FILEVERSION		0, 0, 2, 0

#define PLUGINS_PATH		"plugins/"
#define EXTENSION_PATH		"extensions/"

extern QApplication *g_app;
#endif

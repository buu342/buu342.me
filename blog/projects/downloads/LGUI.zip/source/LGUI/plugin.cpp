// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include "plugin.h"
#include "resource.h"

/**
 ***********************************************************************************************************************
 * Plugin loading
 ***********************************************************************************************************************
 */
Plugin::Plugin(const QString &file_name)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QString file_path = PLUGINS_PATH + file_name;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	m_translator = NULL;
	m_handle = LoadLibrary(file_path.toStdWString().c_str());

	if(m_handle == NULL)
	{
		throw(tr("The plugin <I>%1</I> can't be loaded!").arg(file_name));
	}

	try
	{
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
		fct__get_informations	fct_infos = (fct__get_informations) GetProcAddress(m_handle, FCTNAME_GET_INFORMATIONS);
		fct__get_functions		fct_functions = (fct__get_functions) GetProcAddress(m_handle, FCTNAME_GET_FUNCTIONS);
		fct__get_translator		fct_translator = (fct__get_translator) GetProcAddress(m_handle, FCTNAME_GET_TRANSLATOR);
		/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

		if(fct_infos == NULL || fct_functions == NULL || fct_translator == NULL)
			throw(tr("The plugin <I>%1</I> is an invalid %2 plugin!").arg(file_name).arg(APP_NAME));

		/* Load Translator */
		m_translator = fct_translator();
		if(m_translator != NULL) g_app->installTranslator(m_translator);

		m_infos = fct_infos();
		m_functions = fct_functions();

		setIcon(QIcon(m_infos->icon));
		setData(QString(m_infos->name), Qt::DisplayRole);
		setEditable(false);

		for(QList<plugin_fct>::const_iterator it = m_functions->begin(); it != m_functions->end(); ++it)
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			const plugin_fct	&fct = *it;
			QStandardItem		*item = new QStandardItem(fct.name);
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			item->setIcon(QIcon(fct.icon));
			item->setData(fct.name);
			item->setEditable(false);
			appendRow(item);
		}
	}

	catch(QString & str)
	{
		FreeLibrary(m_handle);
		throw(str);
	}

	catch(...)
	{
		FreeLibrary(m_handle);
		throw(tr("The plugin <I>%1</I> is an invalid %2 plugin!").arg(file_name).arg(APP_NAME));
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
PluginWidget *Plugin::runFunction(const QString &function_name)
{
	try
	{
		for(QList<plugin_fct>::const_iterator it = m_functions->begin(); it != m_functions->end(); ++it)
		{
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
			const plugin_fct	&fct = *it;
			/*~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

			if(!fct.name.compare(function_name))
			{
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
				QString			fct_all_name(tr(FCGNAME_WIDGET).arg(fct.callname));
				fct__get_widget fct_widget = (fct__get_widget) GetProcAddress(m_handle,
																			  fct_all_name.toStdString().c_str());
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

				if(fct_widget == NULL)
				{
					throw(tr("The function <I>%1</I> of <I>%2</I> is an invalid function!").arg(function_name).arg(
							  m_infos->name));
				}

				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
				PluginWidget	*widget = fct_widget();
				/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

				if(widget == NULL)
				{
					throw(tr("The function <I>%1</I> of <I>%2</I> is an invalid function!").arg(function_name).arg(
							  m_infos->name));
				}

				return widget;
			}
		}

		throw(tr("The function <I>%1</I> of <I>%2</I> doesn't exist!").arg(function_name).arg(m_infos->name));
	}

	catch(...)
	{
		throw(tr("The function <I>%1</I> of <I>%2</I> is an invalid function!").arg(function_name).arg(m_infos->name));
	}
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
const plugin_infos &Plugin::getInformations()
{
	return *m_infos;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
const QList<plugin_fct> &Plugin::getFunctions()
{
	return *m_functions;
}

/**
 ***********************************************************************************************************************
 *
 ***********************************************************************************************************************
 */
QTranslator &Plugin::getTranslator()
{
	return *m_translator;
}

/**
 ***********************************************************************************************************************
 * Plugin unloading
 ***********************************************************************************************************************
 */
Plugin::~Plugin()
{
	g_app->removeTranslator(m_translator);
	FreeLibrary(m_handle);
}

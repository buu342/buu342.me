// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#include "stdafx.h"
#include <tchar.h>
#include "lgui.h"
#include "resource.h"

QApplication	*g_app = NULL;

/**
 ***********************************************************************************************************************
 * Program Entry Point
 ***********************************************************************************************************************
 */
int main(int argc, char *argv[])
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~*/
	QDir	dir(EXTENSION_PATH);
	/*~~~~~~~~~~~~~~~~~~~~~~~~*/

	// Add extensions path to DLL paths
	SetDllDirectory(dir.absolutePath().toStdWString().c_str());

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	QApplication	app(argc, argv);
	QTranslator		qtTranslator;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	g_app = &app;
	qtTranslator.load(":/lgui_" + QLocale::system().name().left(2));
	app.installTranslator(&qtTranslator);

	/*~~~~~~*/
	LGUI	w;
	/*~~~~~~*/

	w.show();

	return app.exec();
}

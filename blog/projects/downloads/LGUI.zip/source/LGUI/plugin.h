// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version. See COPYING.txt

#ifndef PLUGIN_H
#define PLUGIN_H
#include <QStringList>
#include <QString>
#include "../LGUI-COMMON/plugin_strct.h"
class Plugin :
	public QObject,
	public QStandardItem
{
	Q_OBJECT
private:
	HMODULE					m_handle;
	QTranslator				*m_translator;
	const plugin_infos		*m_infos;
	const QList<plugin_fct> *m_functions;
public:
	Plugin(const QString &file_name);
	const plugin_infos		&getInformations();
	const QList<plugin_fct> &getFunctions();
	QTranslator				&getTranslator();
	PluginWidget			*runFunction(const QString &function_name);
	~						Plugin();
};
#endif
